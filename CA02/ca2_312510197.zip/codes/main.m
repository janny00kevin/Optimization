clc; clear; close all;
load in_data.mat

res = fcn_checker(x,y);